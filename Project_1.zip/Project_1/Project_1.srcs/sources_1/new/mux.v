`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08.10.2026 21:07:11
// Design Name: 
// Module Name: mux
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// =====================================================================
// FILE: mux.v
// 2-input, 4-bit multiplexer. A mux picks ONE of its inputs.
//   sel = 0 -> y = d0
//   sel = 1 -> y = d1
//
// The CPU uses this module three times:
//   1. Operand MUX     : ALU input B = register Rs  or  immediate
//   2. Write-back MUX  : register data = ALU result or memory data
//   3. PC MUX          : next PC = PC + 1  or  jump address
// =====================================================================
module mux2 (
    input  [3:0] d0,
    input  [3:0] d1,
    input        sel,
    output [3:0] y
);
    assign y = (sel == 1'b1) ? d1 : d0;
endmodule